package com.microsoft.openhack.sample;

import java.util.List;

//class for results
public class word_list {
	public List<String> words;
}

